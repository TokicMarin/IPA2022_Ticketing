<?php
//Datenbankverbindung
include "db_connection.php";

$pdo = pdo_connect_mysql();

if (isset($_GET['status'])) {
    $stmt = $pdo->prepare('UPDATE tickets SET status = ? WHERE ticket_id = ?');
    $stmt->execute([ $_GET['status'], $_GET['id'] ]);
    header('Location: index.php');
    exit;
}
?>
