<?php
//Datenbankverbindung
include "functions.php";
//Holt Ticket_ID aus URL
$id = $_GET['id'];

$del = $pdo->prepare('DELETE * FROM tickets where Ticket_ID=:id');
$del->bindParam(':id', $id, PDO::PARAM_STR);
$del->execute();
header("location:index.php");
?>
