<?php session_start(); ?>
<?php
include 'db_connection.php';
$pdo = pdo_connect_mysql();

$error = "";


if (isset($_POST['titel'], $_POST['name'], $_POST['beschreibung'], $_POST['printscreen'])) {
    if (empty($_POST['titel'])) {
        $error = 'Bitte geben Sie einen Titel an';
      } else if ($_POST["printscreen"] > 500000) {
        $error = "Das Bild darf maximal 5MB gross sein";
      } else {
        $stmt = $pdo->prepare('INSERT INTO tickets (titel, name, beschreibung, printscreen, user_id) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([ $_POST['titel'], $_POST['name'], $_POST['beschreibung'], $_POST['printscreen'], $_SESSION['User_ID'] ]);
    }
}
?>

<?php echo <<<EOT
<!DOCTYPE html>
<html>
	<head>
		<title>"Ticket"</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
    <nav class="navtop">
    	<div>
			<img alt="self-Logo" src="Logo_SwissBanking.svg">
    		<h1>Ticketing-System</h1>
        <a href="index.php">Tickets</a>
    	</div>
    </nav>
EOT; ?>

<div class="form">
	<h2>Erstelle ein Ticket</h2>
    <form action="create.php" method="post">
        <label for="titel">Titel</label><br>
        <input type="text" name="titel" id="titel" required><br>
        <label for="name">Name</label><br>
        <input type="name" name="name" id="name"><br>
        <label for="beschreibung">Beschreibung</label><br>
        <textarea name="beschreibung" placeholder="Bitte beschreiben Sie Ihr Problem" id="beschreibung"></textarea><br>
        <label for="printscreen">Printscreen</label><br>
        <input type="file" name="printscreen" id="printscreen"><br>
        <input class="button" type="submit" value="Erstellen">

    </form>
    <?php if ($error): ?>
    <p><?=$error?></p>
    <?php endif; ?>
</div>
