<?php
session_start();
include 'db_connection.php';
// File mit Datenbankverbindung
$pdo = pdo_connect_mysql();
// Select-Befehl der Tickets aus der Datenbank holt
$stmt = $pdo->prepare('SELECT * FROM tickets ORDER BY Zeit DESC');
$stmt->execute();
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php echo <<<EOT
<!DOCTYPE html>
<html>
	<head>
		<title>"Ticket"</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
    <nav class="navtop">
    	<div>
			<img alt="self-Logo" src="Logo_SwissBanking.svg">
    		<h1>Ticketing-System</h1>
            <a href="index.php">Tickets</a>
    	</div>
    </nav>
EOT;
//HTML Code mit CSS
?>
<div class="tickets">

	<h2>Tickets</h2>

	<p>Unten finden Sie Ihre Tickets</p>
	<?php if ($_SESSION["Admin"] === 1) {
		echo("Hello Admin"); }
			else {
		echo("Hello User");
	};

	if ($_SESSION["User_ID"] > 1) {
		echo("Hello Admin"); }
			else {
		echo("Hello User");
	};
	?>
<br>
<br>
	<a href="create.php" class="button">Erstellen</a>
