<?php
session_start();
include 'db_connection.php';

//Übergabe des Dropdowns an eine Variable und Check ob not null
if(isset($_POST["user"])) {
	$post = $_POST["user"];
	//Splitten des Stings damit nur die ID entnommen wird
	$userid = strtok($post, " ");
} else {

}
$pdo = pdo_connect_mysql();

if(isset($_SESSION['User_ID']) && !empty($_SESSION['User_ID'])) {

} else {
	//Die gesplitte ID in einen Selectbefehl packen damit die nötige User_ID und der Adminwert später in eine Session geschrieben werden können
		$userdata = $pdo->prepare('SELECT vorname, user_id, admin FROM mitarbeitende where User_ID=:userid');
		$userdata->bindParam(':userid', $userid, PDO::PARAM_STR);
		$userdata->execute();
		//fetch anstatt fetchAll damit die Array Keys valide sind
		$id = $userdata->fetch(PDO::FETCH_ASSOC);

		$_SESSION['User_ID'] = $id['user_id'];
		$_SESSION['Admin'] = $id['admin'];

}
//Überprüft ob Session vorhanden
if (!isset($_SESSION["User_ID"]))
	{
		 header("location: login.php");
	}


	if ($_SESSION["Admin"] === 1) {
		if (!isset($_POST["filter"])) {
			$Status = "offen";
			$stmt = $pdo->prepare('SELECT * FROM tickets WHERE Status=:status ORDER BY Zeit DESC');
			$stmt->bindParam(':status', $Status, PDO::PARAM_STR);
			$stmt->execute();
			$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
		} else {
			$stmt = $pdo->prepare('SELECT * FROM tickets WHERE Status=:status ORDER BY Zeit DESC');
			$stmt->bindParam(':status', $_POST["filter"], PDO::PARAM_STR);
			$stmt->execute();
			$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
		}
} else {
	$Status = "offen";
	$stmt = $pdo->prepare('SELECT * FROM tickets WHERE User_ID=:userid AND Status=:status ORDER BY Zeit DESC');
	$stmt->bindParam(':userid', $_SESSION['User_ID'], PDO::PARAM_STR);
	$stmt->bindParam(':status', $Status, PDO::PARAM_STR);
	$stmt->execute();
	$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Select-Befehl der Tickets aus der Datenbank holt mit der User_ID

?>

<?php
//HTML Code mit CSS Anbindung
echo <<<EOT
<!DOCTYPE html>
<html>
	<head>
		<title>"Ticket"</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
    <nav class="navtop">
    	<div>
			<img alt="self-Logo" src="Logo_SwissBanking.svg">
    		<h1><a href="index.php">Ticketing-System</a></h1>
    	</div>
    </nav>
EOT;?>

<div class="header">

	<h2>Tickets</h2>

	<p>Unten finden Sie Ihre Tickets</p>
<br>
<br>
	<a href="create.php" class="button">Erstellen</a>


<br>
<br>
	<div class="tickets">
		<form action="" method="post">
			<input type="submit" value="Filtern" class="button">
				<select action"" name="filter">
					<option>offen</option> <option>gelöscht</option> <option>archiviert</option> </select>
		</form>
		<?php foreach ($tickets as $ticket):?>
		<a href="view.php?id=<?=$ticket['Ticket_ID']?>" class="ticket">
			<span class="con">
			</span>
			<span class="con">
				<span class="Titel"><?=htmlspecialchars($ticket['Titel'], ENT_QUOTES)?></span>
			</span>
			<!--d.m.y. Parameter für Zeitangabe -->
			<span class="Zeit"><?=date('d.m.y, H:i', strtotime($ticket['Zeit']))?></span><br>
		</a>
		<?php endforeach; ?>
	</div>
</div>
