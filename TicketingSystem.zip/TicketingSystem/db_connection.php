<?php
function pdo_connect_mysql() {
    // Datenbankverbindung von https://www.php.net/manual/de/book.pdo.php (PDO Manual)
    $DATABASE_HOST = 'localhost';
    $DATABASE_USER = 'root';
    $DATABASE_PASS = '';
    $DATABASE_NAME = 'ticketing';
    try {
    	return new PDO('mysql:host=' . $DATABASE_HOST . ';dbname=' . $DATABASE_NAME . ';charset=utf8', $DATABASE_USER, $DATABASE_PASS);
    } catch (PDOException $exception) {
    	//Bei fehlgeschlagener Verbindung Error anzeigen
    	exit('Datenbankverbindung fehlgeschlagen!');
    }
}

?>
