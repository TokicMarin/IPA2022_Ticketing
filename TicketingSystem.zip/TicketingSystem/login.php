<?php session_start(); ?>
<?php
include 'db_connection.php';
// File mit Datenbankverbindung
$pdo = pdo_connect_mysql();
// Select-Befehl der Benutzerdaten aus der Datenbank holt
$stmt = $pdo->prepare('SELECT * FROM mitarbeitende');
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>
<?php echo <<<EOT
<!DOCTYPE html>
<html>
	<head>
		<title>"Ticket"</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
    <nav class="navtop">
    	<div>
			<img alt="self-Logo" src="Logo_SwissBanking.svg">
    		<h1><a href="index.php">Ticketing-System</a></h1>
    	</div>
    </nav>
EOT;
//HTML Code mit CSS
?>

<div class="login">

	<h2>Benutzerauswahl</h2>

<form action="index.php" method="post">
  <select name="user">
    <!-- Geht jeden Benutzer durch-->
    <?php foreach ($users as $user) {
      if ($user["Admin"] === 1){
        $admin = "Admin";
        //Wenn true dann Admin
      }else {
        $admin = "Benutzer";
        //Wenn false dann Benutzer
      }
      ?>
      <option><?php echo $user["User_ID"] . " " . $user["Vorname"] . " " . $user["Nachname"] . " " . $admin ?></option>

    <?php }?>
  </select>
  <br>
  <br>
	<input type="submit" class="button" value="Login">

</from>
