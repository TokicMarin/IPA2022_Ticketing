<?php session_start(); ?>
<?php
include 'db_connection.php';
// File mit Datenbankverbindung
$pdo = pdo_connect_mysql();
// Select-Befehl der Benutzerdaten aus der Datenbank holt
$stmt = $pdo->prepare('SELECT * FROM mitarbeitende');
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>
<?php echo <<<EOT
<!DOCTYPE html>
<html>
	<head>
		<title>"Ticket"</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
    <nav class="navtop">
    	<div>
			<img alt="self-Logo" src="Logo_SwissBanking.svg">
    		<h1>Ticketing System</h1>
    	</div>
    </nav>
EOT;
//HTML Code mit CSS
?>

<div class="login">

	<h2>Benutzerauswahl</h2>

<form>
  <select>
    <!-- Geht jeden Benutzer durch-->
    <?php foreach ($users as $user) {
      if ($user["Admin"] === 1){
        $admin = "Admin";
        //Wenn true dann Admin
      }else {
        $admin = "Bentuzer";
        //Wenn false dann Benutzer
      }
      $_SESSION['Admin'] = $user["Admin"];
      $_SESSION['User_ID'] = $user["User_ID"];
      ?>
      <option><?php echo $user["Vorname"] . " " . $user["Nachname"] . " " . $admin ?></option>

    <?php }?>
  </select>
  <br>
  <br>
   <a href="index.php" class="button">Login</a>
</from>
