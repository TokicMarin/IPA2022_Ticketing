<?php session_start();
//Überprüft ob Session vorhanden
if (!isset($_SESSION["User_ID"]))
	{
		 header("location: login.php");
	}
?>
<?php
include 'db_connection.php';
$pdo = pdo_connect_mysql();
$error = "";


$stmt = $pdo->prepare('SELECT * FROM tickets WHERE ticket_id = ?');
$stmt->execute([ $_GET['id'] ]);
$ticket = $stmt->fetch(PDO::FETCH_ASSOC);
// Überprüft Ticket
if (!$ticket) {
    header('Location: index.php');
}


if (isset($_POST['titel'], $_POST['name'], $_POST['beschreibung'], $_POST['printscreen'], $_POST['priorität'] )) {
		if (empty($_POST['titel'])) {
        $error = 'Bitte geben Sie einen Titel an';
      } else if ($_POST["printscreen"] > 500000) {
        $error = "Das Bild darf maximal 5MB gross sein";
      } else {
        $stmt = $pdo->prepare('UPDATE tickets SET titel = ?, name = ?, beschreibung = ?, printscreen = ?, priorität = ? WHERE ticket_id = ?');
        $stmt->execute([ $_POST['titel'], $_POST['name'], $_POST['beschreibung'], $_POST['printscreen'], $_POST['priorität'], $_GET['id'] ]);
        //Redirect auf index.php
        header('Location: view.php?id=' . $_GET['id']);
				exit;
    }
}
?>

<?php echo <<<EOT
<!DOCTYPE html>
<html>
	<head>
		<title>"Ticket"</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
    <nav class="navtop">
    	<div>
			<img alt="self-Logo" src="Logo_SwissBanking.svg">
    		<h1><a href="index.php">Ticketing-System</a></h1>
    	</div>
    </nav>
EOT;?>
//HTML Code mit CSS
?>


<div class="form">
	<h2>Bearbeite dein Ticket</h2>
    <form action="" method="post">
        <label for="titel">Titel</label><br>
        <input type="text" name="titel" id="titel" value="<?php echo htmlspecialchars($ticket['Titel']); ?>" required><br>
        <label for="name">Name</label><br>
        <input type="name" name="name" id="name" value="<?php echo htmlspecialchars($ticket['Name']); ?>"><br>
        <label for="beschreibung">Beschreibung</label><br>
        <textarea name="beschreibung"><?php echo htmlspecialchars($ticket['Beschreibung']); ?></textarea><br>
        <label for="printscreen">Printscreen</label><br>
        <input type="file" name="printscreen" id="printscreen" value=<?php echo htmlspecialchars($ticket['Printscreen']); ?>><br>
				<label for="priorität">Priorität</label><br>
				<select name="priorität"> <option>1</option> <option>2</option> <option>3</option> </select><br>
        <input class="button" type="submit" value="Bearbeiten">

    </form>
    <?php if ($error): ?>
    <p><?=$error?></p>
    <?php endif; ?>
</div>
