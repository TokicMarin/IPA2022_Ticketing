<?php session_start();
include 'db_connection.php';
//Überprüft ob Session vorhanden
if (!isset($_SESSION["User_ID"]))
	{
		 header("location: login.php");
	}

// Datenbankverbindung
$pdo = pdo_connect_mysql();
// Überprüft ID in der URL
if (!isset($_GET['id'])) {
    header("location: index.php");
}
// Selected Ticket mir der übergebenen ID
$stmt = $pdo->prepare('SELECT * FROM tickets WHERE ticket_id = ?');
$stmt->execute([ $_GET['id'] ]);
$ticket = $stmt->fetch(PDO::FETCH_ASSOC);
// Überprüft Ticket
if (!$ticket) {
    exit('Ticket existiert nicht!');
}

if (isset($_GET['status'])) {
    $stmt = $pdo->prepare('UPDATE tickets SET status = ? WHERE ticket_id = ?');
    $stmt->execute([ $_GET['status'], $_GET['id'] ]);
    header('Location: index.php');
    exit;
}

// Falls Kommentar verfasst
if (isset($_POST['Kommentar'])) {
    // Fügt Kommentar in Tabelle ein
    $stmt = $pdo->prepare('UPDATE tickets SET kommentar = ? WHERE ticket_id = ?');
    $stmt->execute([ $_POST['Kommentar'], $_GET['id'] ]);
    header('Location: view.php?id=' . $_GET['id']);
    exit;
}


?>

<?php
//HTML Code mit CSS Anbindung
echo <<<EOT
<!DOCTYPE html>
<html>
	<head>
		<title>"Ticket"</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
    <nav class="navtop">
    	<div>
			<img alt="self-Logo" src="Logo_SwissBanking.svg">
    		<h1><a href="index.php">Ticketing-System</a></h1>
    	</div>
    </nav>
EOT;?>

<h2><?=htmlspecialchars($ticket['Titel'], ENT_QUOTES)?></span></h2>

<h2><?=htmlspecialchars($ticket['Beschreibung'], ENT_QUOTES)?></span></h2>

<h2><?=htmlspecialchars($ticket['Priorität'], ENT_QUOTES)?></span></h2>

<h1>Kommentar<h1>
	<h2><?=htmlspecialchars($ticket['Kommentar'], ENT_QUOTES)?></span></h2>

<?php
if ($_SESSION["Admin"] === 1) {
	//https://stackoverflow.com/questions/11231532/php-inside-html-inside-php
	echo('<div class="btns">
			<a href="delete.php?id=' . $_GET["id"] . '&status=gelöscht" class="button">Löschen</a>
				<a href="delete.php?id=' . $_GET["id"] . '&status=offen" class="button">Öffnen</a>
			<a href="alter.php?id=' . $_GET["id"] . '" class="button">Bearbeiten</a>
			<a href="view.php?id=' . $_GET["id"] . '&status=archiviert" class="button">Archivieren</a><br><br><br><br>

			<form action="" method="post">
					<textarea name="Kommentar" placeholder="Kommentar eingeben"></textarea><br>
					<input type="submit" value="Kommentieren" class="button">
			</form>
	</div>');
} else {
	echo('<div class="btns">
			<a href="delete.php?id=' . $_GET["id"] . '&status=gelöscht" class="button">Löschen</a>
			<a href="alter.php?id=' . $_GET["id"] . '" class="button">Bearbeiten</a>

	</div>');
}

?>
