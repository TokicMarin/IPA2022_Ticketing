<?php session_start();
include 'db_connection.php';
//Überprüft ob Session vorhanden
if (!isset($_SESSION["User_ID"]))
	{
		 header("location: login.php");
	}

// Datenbankverbindung
$pdo = pdo_connect_mysql();
// Überprüft ID in der URL
if (!isset($_GET['id'])) {
    header("location: index.php");
}
// Selected Ticket mir der übergebenen ID
$stmt = $pdo->prepare('SELECT * FROM tickets WHERE ticket_id = ?');
$stmt->execute([ $_GET['id'] ]);
$ticket = $stmt->fetch(PDO::FETCH_ASSOC);
// Überprüft Ticket
if (!$ticket) {
    exit('Ticket existiert nicht!');
}

if (isset($_GET['status'])) {
    $stmt = $pdo->prepare('UPDATE tickets SET status = ? WHERE ticket_id = ?');
    $stmt->execute([ $_GET['status'], $_GET['id'] ]);
    header('Location: index.php');
    exit;
}

if (isset($_GET['kommentiert'])) {
    $stmt = $pdo->prepare('DELETE tickets Where id = ?');
    $stmt->execute([ $_GET['id'] ]);
    header('Location: index.php');
    exit;
}


if (isset($_GET['status']) && in_array($_GET['status'], array('offen', 'geschlossen', 'bearbeitet'))) {
    $stmt = $pdo->prepare('UPDATE tickets SET status = ? WHERE id = ?');
    $stmt->execute([ $_GET['status'], $_GET['id'] ]);
    header('Location: view.php?id=' . $_GET['id']);
    exit;
}


?>

<?php
//HTML Code mit CSS Anbindung
echo <<<EOT
<!DOCTYPE html>
<html>
	<head>
		<title>"Ticket"</title>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
    <nav class="navtop">
    	<div>
			<img alt="self-Logo" src="Logo_SwissBanking.svg">
    		<h1>Ticketing-System</h1>
            <a href="index.php">Tickets</a>
    	</div>
    </nav>
EOT;?>

<h2><?=htmlspecialchars($ticket['Titel'], ENT_QUOTES)?></span></h2>

<h2><?=htmlspecialchars($ticket['Beschreibung'], ENT_QUOTES)?></span></h2>

<?php
if ($_SESSION["Admin"] == 1)
	{
		 echo('<a href="view.php?id=<?=$_GET['id']?>&status=archiviert" class="Button">Archivieren</a>');
	} else {

	}
?>

<div class="btns">
		<a href="delete.php?id=<?=$_GET['id']?>&status=gelöscht" class="Button">Löschen</a>
		<a href="view.php?id=<?=$_GET['id']?>&status=archiviert" class="Button">Archivieren</a>
</div>
