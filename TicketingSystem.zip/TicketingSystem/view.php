<?php
include 'functions.php';
// Datenbankverbindung
$pdo = pdo_connect_mysql();
// Überprüft ID in der URL
if (!isset($_GET['id'])) {
    exit('Keine ID!');
}
// Selected Ticket mir der übergebenen ID
$stmt = $pdo->prepare('SELECT * FROM tickets WHERE ticket_id = ?');
$stmt->execute([ $_GET['id'] ]);
$ticket = $stmt->fetch(PDO::FETCH_ASSOC);
// Überprüft Ticket
if (!$ticket) {
    exit('Ticket existiert nicht!');
}

if (isset($_GET['archiviert'])) {
    $stmt = $pdo->prepare('DELETE tickets Where id = ?');
    $stmt->execute([ $_GET['id'] ]);
    header('Location: index.php');
    exit;
}

if (isset($_GET['kommentiert'])) {
    $stmt = $pdo->prepare('DELETE tickets Where id = ?');
    $stmt->execute([ $_GET['id'] ]);
    header('Location: index.php');
    exit;
}

if (isset($_GET['gelöscht'])) {
    $stmt = $pdo->prepare('DELETE tickets Where id = ?');
    $stmt->execute([ $_GET['id'] ]);
    header('Location: index.php');
    exit;
}

if (isset($_GET['status']) && in_array($_GET['status'], array('offen', 'geschlossen', 'bearbeitet'))) {
    $stmt = $pdo->prepare('UPDATE tickets SET status = ? WHERE id = ?');
    $stmt->execute([ $_GET['status'], $_GET['id'] ]);
    header('Location: view.php?id=' . $_GET['id']);
    exit;
}

?>
